<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableDataMahasiswa extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('table_data_mahasiswa', function (Blueprint $table) {
            $table->id();
            $table->string('namalengkap');
            $table->integer('nik');
            $table->string('tempatlahir');
            $table->integer('tanggallahir');
            $table->string('jeniskelamin');
            $table->string('kewarganegaraan');
            $table->string('agama');
            $table->string('nama_ibu');
            $table->string('email');
            $table->integer('notelp');
            $table->string('alamat');
            $table->integer('kode_pos');
            $table->string('provinsi');
            $table->string('kabupaten');
            $table->string('kecamatan');
            $table->string('pendidikan_terakhir');
            $table->string('namasekolah');
            $table->integer('nilai_ratarata_raport');
            $table->string('program_studi');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('table_data_mahasiswa');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class datamahasiswa extends Model
{

    protected $table = 'table_data_mahasiswa';



    protected $fillable = ['namalengkap', 'nik', 'tempatlahir', 'tanggallahir', 'jeniskelamin', 'kewarganegaraan', 'agama', 'nama_ibu', 'email', 'notelp', 'alamat', 'kode_pos', 'provinsi', 'kabupaten', 'kecamatan', 'pendidikan_terakhir', 'namasekolah', 'nilai_ratarata_raport', 'program_studi' ];
    
}
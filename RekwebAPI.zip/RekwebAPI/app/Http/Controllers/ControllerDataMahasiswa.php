<?php

namespace App\Http\Controllers;

use Laravel\Lumen\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\Models\datamahasiswa;

class ControllerDataMahasiswa extends Controller
{
    public function create(Request $request)
    {
        $data = $request->all();
        $datamahasiswa = datamahasiswa::create($data);

        return response()->json($datamahasiswa);
    }
    public function index()
    {
        $datamahasiswa = datamahasiswa::all();
        return response()->json($datamahasiswa);
    }
    public function detail($id)
    {
        $datamahasiswa = datamahasiswa::find($id);
        return response()->json($datamahasiswa);
    }
    public function update(Request $request, $id)
    {
        $datamahasiswa = datamahasiswa::whereId($id)->update([
            'namalengkap' => $request ->input('namalengkap'),
            'nik' => $request ->input('nik'),
            'tempatlahir'    => $request ->input('tempatlahir'),
            'tanggallahir'     => $request ->input('tanggallahir'),
            'jeniskelamin' => $request ->input('jeniskelamin'),
            'kewarganegaraan' => $request ->input('kewarganegaraan'),
            'agama' => $request ->input('agama'),
            'nama_ibu'    => $request ->input('nama_ibu'),
            'email'     => $request ->input('email'),
            'notelp' => $request ->input('notelp'),
            'alamat' => $request ->input('alamat'),
            'kode_pos' => $request ->input('kode_pos'),
            'provinsi'    => $request ->input('provinsi'),
            'kabupaten'     => $request ->input('kabupaten'),
            'kecamatan' => $request ->input('kecamatan'),
            'pendidikan_terakhir' => $request ->input('pendidikan_terakhir'),
            'namasekolah' => $request ->input('namasekolah'),
            'nilai_ratarata_raport'    => $request ->input('nilai_ratarata_raport'),
            'program_studi'     => $request ->input('program_studi'),
        ]);

        if($datamahasiswa){
            return response()->json([
                'success' => true,
                'message' => 'Data Berhasil Di Update',
                'data' => $datamahasiswa
            ],201);

        }else{
            return response ()->json([
                'success' => false,
                'message' => 'Data Gagal Di Update',
            ],400);
        }
    }
    public function delete($id)
    {
        $datamahasiswa = datamahasiswa::whereId($id)->first();
        $datamahasiswa->delete();

        if($datamahasiswa)
        {
            return response()->json([
                'success' => true,
                'message' => 'Data Berhasil Dihapus'
            ],200);
        }
    }
}